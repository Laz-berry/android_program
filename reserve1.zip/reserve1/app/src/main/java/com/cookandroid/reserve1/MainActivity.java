package com.cookandroid.reserve1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;


public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {
    Chronometer ch;
    Button btnStart, btnEnd;
    FrameLayout caltime;
    RadioGroup rGroup;
    CalendarView cv;
    TimePicker tp;
    RadioButton rdoDate, rdoTime;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch = (Chronometer) findViewById(R.id.ch);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnEnd = (Button) findViewById(R.id.btnEnd);
        caltime = (FrameLayout) findViewById(R.id.caltime);
        rGroup = (RadioGroup) findViewById(R.id.rGroup);
        cv = (CalendarView) findViewById(R.id.cal);
        tp = (TimePicker) findViewById(R.id.time);
        rdoDate = (RadioButton) findViewById(R.id.rdoDate);
        rdoTime = (RadioButton) findViewById(R.id.rdoTime);
        txtResult = (TextView) findViewById(R.id.txtResult);

        btnStart.setOnClickListener(this);
        btnEnd.setOnClickListener(this);

        rdoDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                cv.setVisibility(View.VISIBLE);
                tp.setVisibility(View.INVISIBLE);

            }
        });

        rdoTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                cv.setVisibility(View.INVISIBLE);
                tp.setVisibility(View.VISIBLE);

            }
        });

    }



    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnStart:
                rGroup.setVisibility(View.VISIBLE);
                caltime.setVisibility(View.VISIBLE);
                btnStart.setEnabled(false);
                btnEnd.setEnabled(true);
                ch.setTextColor(Color.RED);
                ch.setBase(SystemClock.elapsedRealtime());
                ch.start();
                break;
            case R.id.btnEnd:
                rGroup.setVisibility(View.INVISIBLE);
                caltime.setVisibility(View.INVISIBLE);
                btnStart.setEnabled(true);
                btnEnd.setEnabled(false);
                ch.setTextColor(Color.BLUE);
                ch.stop();

                long time = cv.getDate();
                Calendar cal = Calendar.getInstance();
                cal.setTime(new Date(time));

                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH) + 1;
                int day = cal.get(Calendar.DAY_OF_MONTH);

                int hour = tp.getCurrentHour();
                int minute = tp.getCurrentMinute();

                txtResult.setText(
                        year+"년"+month+"월"+day+"일"+
                                hour+"시"+minute+"분");

                break;
        }

    }
}
[출처] 안드로이드(Android) - 캘린더, 타임피커 이용한 예약날짜, 시간 받아오기 예제|작성자 별똥별사람

