package com.cookandroid.intent;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class SubActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        TextView tx1 = (TextView)findViewById(R.id.textView1); /*TextView선언*/
        TextView tx2 = (TextView)findViewById(R.id.textView2);
        TextView tx3 = (TextView)findViewById(R.id.textView3);
        TextView tx4 = (TextView)findViewById(R.id.textView4);
        TextView tx5 = (TextView)findViewById(R.id.textView5);

        Intent intent = getIntent(); /*데이터 수신*/

        String name = intent.getExtras().getString("name"); /*String형*/
        tx1.setText(name);

        int age = intent.getExtras().getInt("age"); /*int형*/
        tx2.setText(String.valueOf(age));

        String array[] = intent.getExtras().getStringArray("array"); /*배열*/
        String add_array="";
        for(int i=0;i<array.length;i++){
            add_array+=array[i]+",";
        }
        tx3.setText(add_array);

        Option option = (Option)intent.getSerializableExtra("class"); /*클래스*/
        tx4.setText(option.getPhone());
        tx5.setText(option.getAddr());

    }
}
