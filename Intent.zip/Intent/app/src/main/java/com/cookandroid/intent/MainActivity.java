package com.cookandroid.intent;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sub = (Button)findViewById(R.id.button);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] array = {"동생","아버지","어머니"}; /*송신 할 배열*/
                Option option = new Option("010xxxxxxxx","경기안산시xxxx"); /*송신 할 클래스*/

                Intent intent = new Intent(getApplicationContext(), SubActivity.class);

                intent.putExtra("name","박준석"); /*송신*/
                intent.putExtra("age",23);
                intent.putExtra("array",array);
                intent.putExtra("class",option);

                startActivity(intent);
            }
        });
    }
}
