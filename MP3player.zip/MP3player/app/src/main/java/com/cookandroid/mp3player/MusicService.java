package com.cookandroid.mp3player;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.app.Service;
import android.os.IBinder;
import android.media.MediaPlayer;

public class MusicService extends Service {

    private MediaPlayer mediaPlayer;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate(){
        android.util.Log.i("서비스 테스트","onCreate()");
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        android.util.Log.i("서비스 테스트","onDestroy()");
        mediaPlayer.stop();  //음악 중지
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        android.util.Log.i("서비스 테스트","onStartCommand()");
        mediaPlayer = MediaPlayer.create(this,R.raw.alarm);  //mp3시작 및 반복
        mediaPlayer.setLooping(true);
        mediaPlayer.start();
        return super.onStartCommand(intent, flags, startId);
    }
}